package com.emeboy04.potionskill;

import org.bukkit.potion.PotionEffect;

import java.util.List;

/** Satu skill = nama + daftar potion effect yang diberikan saat diaktifkan. */
public record Skill(String id, String displayName, List<PotionEffect> effects) {
}
