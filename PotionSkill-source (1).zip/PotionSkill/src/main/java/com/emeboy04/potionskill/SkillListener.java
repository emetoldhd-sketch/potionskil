package com.emeboy04.potionskill;

import net.kyori.adventure.text.Component;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.scoreboard.Team;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class SkillListener implements Listener {

    private final PotionSkillPlugin plugin;
    private final SkillManager manager;
    private final Map<UUID, Long> cooldowns = new HashMap<>();

    public SkillListener(PotionSkillPlugin plugin, SkillManager manager) {
        this.plugin = plugin;
        this.manager = manager;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getConfig().getBoolean("assign-on-join", true)) return;

        if (!manager.hasSkill(player.getUniqueId())) {
            Skill skill = manager.assignRandom(player.getUniqueId());
            if (skill != null) {
                player.sendMessage(plugin.msg("assigned")
                        .replaceText(b -> b.matchLiteral("%skill%")
                                .replacement(PotionSkillPlugin.color(skill.displayName()))));
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        cooldowns.remove(event.getPlayer().getUniqueId());
    }

    /** Tombol F = swap item ke offhand. Kalau sambil Shift, kita pakai sebagai skill. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onSwap(PlayerSwapHandItemsEvent event) {
        Player player = event.getPlayer();

        if (plugin.getConfig().getBoolean("require-sneak", true) && !player.isSneaking()) {
            return; // F biasa tetap berfungsi normal (tukar item)
        }

        event.setCancelled(true); // cegah item tertukar ke offhand

        if (!player.hasPermission("potionskill.use")) {
            player.sendMessage(plugin.msg("no-permission"));
            return;
        }

        Skill skill = manager.getPlayerSkill(player.getUniqueId());
        if (skill == null) {
            player.sendMessage(plugin.msg("no-skill"));
            return;
        }

        long now = System.currentTimeMillis();
        long cooldownMs = plugin.getConfig().getLong("cooldown-seconds", 30) * 1000L;
        long readyAt = cooldowns.getOrDefault(player.getUniqueId(), 0L);

        if (now < readyAt) {
            double left = Math.ceil((readyAt - now) / 100.0) / 10.0;
            Component m = plugin.msg("cooldown")
                    .replaceText(b -> b.matchLiteral("%time%").replacement(String.valueOf(left)));
            player.sendActionBar(m);
            return;
        }

        List<LivingEntity> targets = findTargets(player);
        if (targets.isEmpty()) {
            // tidak ada musuh -> cooldown tidak terpakai
            player.sendActionBar(plugin.msg("no-target"));
            return;
        }

        Component skillName = PotionSkillPlugin.color(skill.displayName());

        for (LivingEntity target : targets) {
            for (PotionEffect effect : skill.effects()) {
                target.addPotionEffect(effect);
            }

            Location loc = target.getLocation().add(0, 1, 0);
            target.getWorld().spawnParticle(Particle.SMOKE, loc, 25, 0.3, 0.5, 0.3, 0.02);

            if (target instanceof Player victim) {
                victim.playSound(victim.getLocation(), Sound.ENTITY_WITHER_SHOOT, 0.6f, 1.2f);
                victim.sendActionBar(plugin.msg("hit")
                        .replaceText(b -> b.matchLiteral("%skill%").replacement(skillName))
                        .replaceText(b -> b.matchLiteral("%player%").replacement(player.getName())));
            }
        }

        cooldowns.put(player.getUniqueId(), now + cooldownMs);

        int count = targets.size();
        player.playSound(player.getLocation(), Sound.ENTITY_EVOKER_CAST_SPELL, 1f, 1f);
        player.sendActionBar(plugin.msg("used")
                .replaceText(b -> b.matchLiteral("%skill%").replacement(skillName))
                .replaceText(b -> b.matchLiteral("%count%").replacement(String.valueOf(count))));
    }

    /** Cari musuh di sekitar player (player lain, dan opsional monster). */
    private List<LivingEntity> findTargets(Player caster) {
        double radius = plugin.getConfig().getDouble("radius", 8.0);
        boolean mobs = plugin.getConfig().getBoolean("affect-hostile-mobs", false);
        boolean ignoreTeam = plugin.getConfig().getBoolean("ignore-same-team", true);

        List<LivingEntity> result = new ArrayList<>();
        Location center = caster.getLocation();

        for (Entity e : caster.getNearbyEntities(radius, radius, radius)) {
            if (e.getWorld() != center.getWorld()) continue;
            if (e.getLocation().distanceSquared(center) > radius * radius) continue;

            if (e instanceof Player target) {
                if (target.getUniqueId().equals(caster.getUniqueId())) continue;
                GameMode gm = target.getGameMode();
                if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) continue;
                if (ignoreTeam && sameTeam(caster, target)) continue;
                result.add(target);
            } else if (mobs && e instanceof Monster monster) {
                result.add(monster);
            }
        }
        return result;
    }

    private boolean sameTeam(Player a, Player b) {
        Team team = a.getScoreboard().getEntryTeam(a.getName());
        return team != null && team.hasEntry(b.getName());
    }
}
