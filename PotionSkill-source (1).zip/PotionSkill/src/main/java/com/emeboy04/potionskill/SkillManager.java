package com.emeboy04.potionskill;

import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

public class SkillManager {

    private final PotionSkillPlugin plugin;
    private final Map<String, Skill> skills = new LinkedHashMap<>();
    private final Map<UUID, String> assigned = new HashMap<>();
    private final File dataFile;
    private YamlConfiguration data;

    public SkillManager(PotionSkillPlugin plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "players.yml");
    }

    /** Muat skill dari config.yml dan data player dari players.yml. */
    public void load() {
        plugin.reloadConfig();
        skills.clear();
        assigned.clear();

        ConfigurationSection section = plugin.getConfig().getConfigurationSection("skills");
        if (section != null) {
            for (String id : section.getKeys(false)) {
                ConfigurationSection s = section.getConfigurationSection(id);
                if (s == null) continue;

                String display = s.getString("display-name", id);
                List<PotionEffect> effects = new ArrayList<>();

                for (String line : s.getStringList("effects")) {
                    PotionEffect effect = parseEffect(line);
                    if (effect == null) {
                        plugin.getLogger().warning("Effect tidak valid di skill '" + id + "': " + line);
                    } else {
                        effects.add(effect);
                    }
                }

                if (effects.isEmpty()) {
                    plugin.getLogger().warning("Skill '" + id + "' dilewati (tidak ada effect valid).");
                    continue;
                }
                skills.put(id.toLowerCase(Locale.ROOT), new Skill(id.toLowerCase(Locale.ROOT), display, effects));
            }
        }

        data = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection players = data.getConfigurationSection("players");
        if (players != null) {
            for (String uuid : players.getKeys(false)) {
                try {
                    assigned.put(UUID.fromString(uuid), players.getString(uuid));
                } catch (IllegalArgumentException ignored) {
                }
            }
        }
    }

    /** Format: "nama_effect:durasi_detik:level" */
    private PotionEffect parseEffect(String line) {
        String[] p = line.split(":");
        if (p.length < 1) return null;
        try {
            NamespacedKey key = NamespacedKey.minecraft(p[0].trim().toLowerCase(Locale.ROOT));
            PotionEffectType type = Registry.POTION_EFFECT_TYPE.get(key);
            if (type == null) return null;

            int seconds = p.length > 1 ? Integer.parseInt(p[1].trim()) : 10;
            int amplifier = p.length > 2 ? Integer.parseInt(p[2].trim()) : 0;
            return new PotionEffect(type, seconds * 20, amplifier, false, true, true);
        } catch (Exception e) {
            return null;
        }
    }

    public void save() {
        if (data == null) data = new YamlConfiguration();
        data.set("players", null);
        for (Map.Entry<UUID, String> e : assigned.entrySet()) {
            data.set("players." + e.getKey(), e.getValue());
        }
        try {
            plugin.getDataFolder().mkdirs();
            data.save(dataFile);
        } catch (IOException ex) {
            plugin.getLogger().severe("Gagal menyimpan players.yml: " + ex.getMessage());
        }
    }

    public Map<String, Skill> getSkills() {
        return skills;
    }

    public Skill getSkill(String id) {
        return id == null ? null : skills.get(id.toLowerCase(Locale.ROOT));
    }

    public Skill getPlayerSkill(UUID uuid) {
        return getSkill(assigned.get(uuid));
    }

    public boolean hasSkill(UUID uuid) {
        return getPlayerSkill(uuid) != null;
    }

    public void setSkill(UUID uuid, Skill skill) {
        assigned.put(uuid, skill.id());
        save();
    }

    /** Beri skill acak. */
    public Skill assignRandom(UUID uuid) {
        if (skills.isEmpty()) return null;
        List<Skill> list = new ArrayList<>(skills.values());
        Skill skill = list.get(ThreadLocalRandom.current().nextInt(list.size()));
        setSkill(uuid, skill);
        return skill;
    }
}
